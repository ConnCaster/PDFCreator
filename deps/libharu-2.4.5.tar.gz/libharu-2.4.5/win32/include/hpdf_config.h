/* include/hpdf_config.h.in.  Generated from configure.in by autoheader.  */

/* Define to 1 if you have the `png' library (-lpng). */
#define LIBHPDF_HAVE_LIBPNG 1

/* Define to 1 if you have the `z' library (-lz). */
#define LIBHPDF_HAVE_ZLIB 1

/* define pi */
#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif  /*  M_PI  */

/* debug build */
#undef LIBHPDF_DEBUG

/* debug trace enabled */
#undef LIBHPDF_DEBUG_TRACE
